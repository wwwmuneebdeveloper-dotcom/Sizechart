<?php
/*
Plugin Name: WooCommerce Size Chart Popup
Description: Adds a "View Size Chart" button with a popup that renders the [wpcsc id='2925'] shortcode on single product pages.
Version: 1.0.0
Author: ChatGPT
License: GPL2+
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WPC_SIZE_CHART_SHORTCODE', "[wpcsc id='2925']" );

/**
 * Enqueue inline CSS & JS only on single product pages.
 */
add_action( 'wp_enqueue_scripts', function () {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) {
        return;
    }

    // CSS
    wp_register_style( 'wpc-size-chart-popup', false );
    wp_enqueue_style( 'wpc-size-chart-popup' );
    wp_add_inline_style( 'wpc-size-chart-popup', '
        #size-chart-modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            justify-content: center;
            align-items: center;
        }
        .size-chart-content {
            background: #fff;
            padding: 20px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            border-radius: 8px;
            position: relative;
            box-shadow: 0 10px 30px rgba(0,0,0,.2);
        }
        #size-chart-close {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 22px;
            cursor: pointer;
            line-height: 1;
        }
    ' );

    // JS
    wp_register_script( 'wpc-size-chart-popup', '', array( 'jquery' ), false, true );
    wp_enqueue_script( 'wpc-size-chart-popup' );
    wp_add_inline_script( 'wpc-size-chart-popup', "
        jQuery(function($){
            $(document).on('click', '#size-chart-btn', function(e){
                e.preventDefault();
                $('#size-chart-modal').css('display', 'flex');
            });
            $(document).on('click', '#size-chart-close', function(){
                $('#size-chart-modal').hide();
            });
            $(document).on('click', function(e){
                if (e.target && e.target.id === 'size-chart-modal') {
                    $('#size-chart-modal').hide();
                }
            });
        });
    " );
}, 99 );

/**
 * Output the button & popup after the Add to Cart button.
 */
add_action( 'woocommerce_after_add_to_cart_button', function () {
    echo '<button id="size-chart-btn" class="button" type="button">' . esc_html__( 'View Size Chart', 'wpc-size-chart-popup' ) . '</button>';
    echo '<div id="size-chart-modal"><div class="size-chart-content">';
    echo do_shortcode( WPC_SIZE_CHART_SHORTCODE );
    echo '<span id="size-chart-close">&times;</span></div></div>';
} );
